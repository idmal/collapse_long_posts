<?php

return [
    'CollapseLongPosts: Expand' => 'باز کردن کامل',
    'CollapseLongPosts: Collapse' => 'بستن',

    'Collapse Long Posts' => 'جمع‌کردن نوشته‌های طولانی',

    'Automatically collapse long posts to keep your forum clean — users can expand or collapse anytime.' =>
        'جمع‌کردن خودکار نوشته‌های طولانی برای خلوت‌تر ماندن انجمن؛ کاربران هر زمان می‌توانند آن را باز یا بسته کنند.',

    'Enable auto-collapse' =>
        'فعال‌سازی جمع‌کردن خودکار',

    'Collapse threshold (px)' =>
        'آستانه جمع‌کردن (پیکسل)',
];